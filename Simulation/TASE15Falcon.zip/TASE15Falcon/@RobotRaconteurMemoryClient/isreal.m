function n=isreal(obj)

n=RobotRaconteurMex('MemoryOp',obj.rrobjecttype,obj.rrstubid,obj.rrmembername,'isreal');