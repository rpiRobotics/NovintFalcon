function n=length(obj)

n=max(RobotRaconteurMex('MemoryOp',obj.rrobjecttype,obj.rrstubid,obj.rrmembername,'size'));