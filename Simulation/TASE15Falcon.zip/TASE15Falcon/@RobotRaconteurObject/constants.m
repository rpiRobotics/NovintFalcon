function t=constants(obj)

t=RobotRaconteurMex('constants',obj.rrobjecttype,obj.rrstubid);