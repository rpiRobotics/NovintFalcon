function disableevents(obj)

RobotRaconteurMex('disableevents',obj.rrobjecttype,obj.rrstubid);