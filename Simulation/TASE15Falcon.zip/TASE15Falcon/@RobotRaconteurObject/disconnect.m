function rrdisconnect(obj)

RobotRaconteurMex('Disconnect',obj.rrobjecttype,obj.rrstubid);