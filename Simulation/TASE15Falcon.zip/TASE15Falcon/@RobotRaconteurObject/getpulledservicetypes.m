function types=getpulledservicetypes(obj)

types=RobotRaconteurMex('GetPulledServiceTypes',obj.rrobjecttype,obj.rrstubid);