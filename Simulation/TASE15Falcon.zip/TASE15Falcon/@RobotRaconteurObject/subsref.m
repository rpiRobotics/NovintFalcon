function  value = subsref( obj, S )
value=RobotRaconteurMex('subsref',obj.rrobjecttype,obj.rrstubid,S);

end

